# Autor: Francisco Orozco

$ruta = "C:\Program Files (x86)\Dropbox\Client\DropboxUninstaller.exe"
Start-Process $ruta /S -Wait